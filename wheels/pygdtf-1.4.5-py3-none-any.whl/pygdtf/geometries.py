# MIT License
#
# Copyright (C) 2025 vanous
#
# This file is part of pygdtf.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import copy
from typing import List, Optional, TYPE_CHECKING
from xml.etree import ElementTree
from xml.etree.ElementTree import Element

from .base_node import BaseNode
from .dmxbreak import *
from .value import *  # type: ignore

if TYPE_CHECKING:
    from . import FixtureType


def _matrix_to_str(matrix: "Matrix") -> str:
    if hasattr(matrix, "raw") and matrix.raw:
        return matrix.raw
    rows = []
    for row in matrix.matrix:
        rows.append(",".join(f"{value:.6f}" for value in row))
    return "".join("{" + row + "}" for row in rows)


class Geometries(list):
    def _resolve_root_geometry(
        self,
        fixture_type: "FixtureType",
        mode_name: Optional[str] = None,
        mode_index: Optional[int] = None,
    ):
        root_name = None
        if mode_name is not None:
            mode = fixture_type.dmx_modes.get_mode_by_name(mode_name)
            if mode is not None:
                root_name = mode.geometry
        elif mode_index is not None and len(fixture_type.dmx_modes) > mode_index:
            root_name = fixture_type.dmx_modes[mode_index].geometry
        if root_name is None and len(self):
            root_name = self[0].name
        if root_name is None:
            return None
        return self.get_geometry_by_name(root_name)

    def get_geometry_by_name(self, geometry_name):
        """Operates on the while kinematic chain of the device"""

        def iterate_geometries(collector):
            if hasattr(collector, "name"):
                if collector.name == geometry_name:
                    matched.append(collector)

            iterator = collector
            if hasattr(collector, "geometries"):
                iterator = collector.geometries

            for g in iterator:
                if g.name == geometry_name:
                    matched.append(g)
                if hasattr(g, "geometries"):
                    iterate_geometries(g)

        matched: List["Geometry"] = []
        iterate_geometries(self)
        if matched:
            return matched[0]

        return None

    @staticmethod
    def get_geometry_by_type(
        root_geometry: Optional["Geometry"] = None,
        geometry_class: Optional["Geometry"] = None,
    ) -> List["Geometry"]:
        """Recursively find all geometries of a given type. Requires a root geometry"""

        def iterate_geometries(collector):
            for g in collector.geometries:
                if type(g) is geometry_class:
                    matched.append(g)
                if hasattr(g, "geometries"):
                    iterate_geometries(g)

        matched: List["Geometry"] = []
        iterate_geometries(root_geometry)
        return matched

    def get_geometry_tree(
        self,
        fixture_type: "FixtureType",
        mode_name: Optional[str] = None,
        mode_index: Optional[int] = None,
    ):
        root_geometry = self._resolve_root_geometry(
            fixture_type,
            mode_name=mode_name,
            mode_index=mode_index,
        )
        return self._expand_tree(root_geometry, fixture_type, _visited=set())

    def _expand_tree(
        self,
        geometry,
        fixture_type: "FixtureType",
        _visited: Optional[set] = None,
    ):
        if geometry is None:
            return None
        if _visited is None:
            _visited = set()
        if isinstance(geometry, GeometryReference):
            reference_geometry = self._resolve_reference(geometry, fixture_type)
            if reference_geometry is not None:
                ref_key = (reference_geometry.name, type(reference_geometry))
                if ref_key in _visited:
                    return None
                _visited.add(ref_key)
        geometry_copy = copy.deepcopy(geometry)
        if isinstance(geometry, GeometryReference):
            reference_geometry = self._resolve_reference(geometry, fixture_type)
            reference_root = None
            if reference_geometry is not None:
                try:
                    reference_root = self._expand_tree(
                        reference_geometry,
                        fixture_type,
                        _visited=_visited,
                    )
                finally:
                    ref_key = (reference_geometry.name, type(reference_geometry))
                    _visited.discard(ref_key)
            geometry_copy.reference_root = reference_root
            geometry_copy.geometries = Geometries(
                reference_root.geometries if reference_root is not None else [],
            )
        else:
            children = []
            for child in self._iter_children(geometry, fixture_type, True):
                child_key = (getattr(child, "name", None), type(child))
                if child_key in _visited:
                    continue
                _visited.add(child_key)
                try:
                    child_copy = self._expand_tree(
                        child,
                        fixture_type,
                        _visited=_visited,
                    )
                finally:
                    _visited.discard(child_key)
                if child_copy is not None:
                    children.append(child_copy)
            geometry_copy.geometries = Geometries(children)
        return geometry_copy

    def _resolve_reference(self, geometry, fixture_type: "FixtureType"):
        if isinstance(geometry, GeometryReference):
            reference_name = geometry.geometry
            if reference_name:
                return fixture_type.geometries.get_geometry_by_name(reference_name)
        return None

    def _iter_children(self, geometry, fixture_type: "FixtureType", expand_references):
        if isinstance(geometry, GeometryReference):
            reference_geometry = self._resolve_reference(geometry, fixture_type)
            if expand_references and reference_geometry is not None:
                return getattr(reference_geometry, "geometries", [])
            return []
        return getattr(geometry, "geometries", [])

    def iter_tree(self, geometry, fixture_type: "FixtureType", expand_references=True):
        if geometry is None:
            return
        yield geometry
        for child in self._iter_children(geometry, fixture_type, expand_references):
            yield from self.iter_tree(child, fixture_type, expand_references)

    def to_list(self, geometry, fixture_type: "FixtureType", expand_references=True):
        return list(self.iter_tree(geometry, fixture_type, expand_references))

    def as_dict(
        self,
        geometry=None,
        fixture_type: Optional["FixtureType"] = None,
        mode_name: Optional[str] = None,
        mode_index: Optional[int] = None,
        _visited: Optional[set] = None,
    ):
        if fixture_type is None:
            raise ValueError("fixture_type is required to build geometry dicts.")
        if geometry is None:
            geometry = self._resolve_root_geometry(
                fixture_type,
                mode_name=mode_name,
                mode_index=mode_index,
            )
        if geometry is None:
            return None
        reference_geometry = self._resolve_reference(geometry, fixture_type)
        model = geometry.model
        if model is None and reference_geometry is not None:
            model = reference_geometry.model

        def _collect_types(node) -> List[str]:
            types: List[str] = []
            if node is None:
                return types
            types.append(type(node).__name__)
            for child in self._iter_children(node, fixture_type, True):
                types.extend(_collect_types(child))
            return types

        contains_types = sorted(set(_collect_types(geometry)))
        reference_contains_types = (
            sorted(set(_collect_types(reference_geometry)))
            if reference_geometry is not None
            else []
        )
        resolved_type = (
            type(reference_geometry).__name__
            if reference_geometry is not None
            else type(geometry).__name__
        )
        data = {
            "name": geometry.name,
            "type": type(geometry).__name__,
            "resolved_type": resolved_type,
            "reference_type": type(reference_geometry).__name__
            if reference_geometry is not None
            else None,
            "contains_types": contains_types,
            "reference_contains_types": reference_contains_types,
            "model": model,
            "matrix": geometry.position.matrix
            if hasattr(geometry, "position")
            else None,
            "reference": geometry.geometry
            if isinstance(geometry, GeometryReference)
            else None,
        }
        if _visited is None:
            _visited = set()
        if isinstance(geometry, GeometryReference) and reference_geometry is not None:
            ref_key = (reference_geometry.name, type(reference_geometry).__name__)
            if ref_key not in _visited:
                _visited.add(ref_key)
                try:
                    data["reference_data"] = self.as_dict(
                        reference_geometry,
                        fixture_type,
                        _visited=_visited,
                    )
                finally:
                    _visited.discard(ref_key)
        children = []
        for child in self._iter_children(
            geometry,
            fixture_type,
            True,
        ):
            child_key = (getattr(child, "name", None), type(child).__name__)
            if child_key in _visited:
                continue
            _visited.add(child_key)
            try:
                child_data = self.as_dict(
                    child,
                    fixture_type,
                    _visited=_visited,
                )
            finally:
                _visited.discard(child_key)
            if child_data is not None:
                children.append(child_data)
        data["children"] = children
        return data


class Geometry(BaseNode):
    def __init__(
        self,
        name: Optional[str] = None,
        parent_name: Optional[str] = None,
        model: Optional[str] = None,
        position: "Matrix" = Matrix(0),
        geometries: Optional[List] = None,
        *args,
        **kwargs,
    ):
        self.name = name
        self.parent_name = parent_name
        self.model = model
        self.position = position
        if geometries is not None:
            self.geometries = geometries
        else:
            self.geometries = Geometries()
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element", xml_parent: Optional["Element"] = None):
        self.name = xml_node.attrib.get("Name")
        if xml_parent is not None:
            self.parent_name = xml_parent.get("Name")

        self.model = xml_node.attrib.get("Model")
        self.position = Matrix(xml_node.attrib.get("Position", 0))
        for child in list(xml_node):
            cls = TAG_TO_GEOMETRY_CLASS.get(child.tag)
            if cls:
                self.geometries.append(cls(xml_node=child, xml_parent=xml_node))

    def __str__(self):
        return f"{self.name} ({self.model})"

    def _tag(self):
        tag = CLASS_TO_GEOMETRY_TAG.get(type(self))
        if tag:
            return tag
        raise KeyError(
            f"Geometry class not registered in mapping: {type(self).__name__}"
        )

    def to_xml(self):
        attrs = {}
        if self.name is not None:
            attrs["Name"] = self.name
        if self.model is not None:
            attrs["Model"] = self.model
        if self.position is not None:
            attrs["Position"] = _matrix_to_str(self.position)

        element = Element(self._tag(), attrs)
        for child in getattr(self, "geometries", []):
            try:
                element.append(child.to_xml())
            except NotImplementedError as exc:
                raise NotImplementedError(
                    f"Child geometry {type(child).__name__} missing to_xml implementation"
                ) from exc
        return element


class GeometryAxis(Geometry):
    pass


class GeometryFilterBeam(Geometry):
    pass


class GeometryFilterColor(Geometry):
    pass


class GeometryFilterGobo(Geometry):
    pass


class GeometryFilterShaper(Geometry):
    pass


class GeometryMediaServerLayer(Geometry):
    pass


class GeometryMediaServerCamera(Geometry):
    pass


class GeometryMediaServerMaster(Geometry):
    pass


class GeometryDisplay(Geometry):
    def __init__(self, texture: Optional[str] = None, *args, **kwargs):
        self.texture = texture

        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element", xml_parent: Optional["Element"] = None):
        super()._read_xml(xml_node, xml_parent)
        self.texture = xml_node.attrib.get("texture")


class GeometryStructure(Geometry):
    def __init__(
        self,
        linked_geometry: Optional[str] = None,
        structure_type: StructureType = StructureType(None),
        cross_section_type: CrossSectionType = CrossSectionType(None),
        cross_section_height: float = 0,
        cross_section_wall_thickness: float = 0,
        truss_cross_section: Optional[str] = None,
        *args,
        **kwargs,
    ):
        self.linked_geometry = linked_geometry
        self.structure_type = structure_type
        self.cross_section_type = cross_section_type
        self.cross_section_height = cross_section_height
        self.cross_section_wall_thickness = cross_section_wall_thickness
        self.truss_cross_section = truss_cross_section

        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element", xml_parent: Optional["Element"] = None):
        super()._read_xml(xml_node, xml_parent)
        self.linked_geometry = xml_node.attrib.get("LinkedGeometry")
        self.structure_type = StructureType(xml_node.attrib.get("StructureType"))
        self.cross_section_type = CrossSectionType(
            xml_node.attrib.get("CrossSectionType")
        )
        self.cross_section_height = float(xml_node.attrib.get("CrossSectionHeight", 0))
        self.cross_section_wall_thickness = float(
            xml_node.attrib.get("CrossSectionWallThickness", 0)
        )
        self.truss_cross_section = xml_node.attrib.get("TrussCrossSection")


class GeometrySupport(Geometry):
    def __init__(
        self,
        support_type: SupportType = SupportType(None),
        rope_cross_section: Optional[str] = None,
        rope_offset: Vector3 = Vector3(0),
        capacity_x: float = 0,
        capacity_y: float = 0,
        capacity_z: float = 0,
        capacity_xx: float = 0,
        capacity_yy: float = 0,
        capacity_zz: float = 0,
        resistance_x: float = 0,
        resistance_y: float = 0,
        resistance_z: float = 0,
        resistance_xx: float = 0,
        resistance_yy: float = 0,
        resistance_zz: float = 0,
        *args,
        **kwargs,
    ):
        self.support_type = support_type
        self.rope_cross_section = rope_cross_section
        self.rope_offset = rope_offset
        self.capacity_x = capacity_x
        self.capacity_y = capacity_y
        self.capacity_z = capacity_z
        self.capacity_xx = capacity_xx
        self.capacity_yy = capacity_yy
        self.capacity_zz = capacity_zz
        self.resistance_x = resistance_x
        self.resistance_y = resistance_y
        self.resistance_z = resistance_z
        self.resistance_xx = resistance_xx
        self.resistance_yy = resistance_yy
        self.resistance_zz = resistance_zz

        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element", xml_parent: Optional["Element"] = None):
        super()._read_xml(xml_node, xml_parent)
        self.support_type = SupportType(xml_node.attrib.get("SupportType"))
        self.rope_cross_section = xml_node.attrib.get("RopeCrossSection")
        self.rope_offset = Vector3(xml_node.attrib.get("RopeOffset", 0))
        self.capacity_x = float(xml_node.attrib.get("CapacityX", 0))
        self.capacity_y = float(xml_node.attrib.get("CapacityY", 0))
        self.capacity_z = float(xml_node.attrib.get("CapacityZ", 0))
        self.capacity_xx = float(xml_node.attrib.get("CapacityXX", 0))
        self.capacity_yy = float(xml_node.attrib.get("CapacityYY", 0))
        self.capacity_zz = float(xml_node.attrib.get("CapacityZZ", 0))
        self.resistance_x = float(xml_node.attrib.get("ResistanceX", 0))
        self.resistance_y = float(xml_node.attrib.get("ResistanceY", 0))
        self.resistance_z = float(xml_node.attrib.get("ResistanceZ", 0))
        self.resistance_xx = float(xml_node.attrib.get("ResistanceXX", 0))
        self.resistance_yy = float(xml_node.attrib.get("ResistanceYY", 0))
        self.resistance_zz = float(xml_node.attrib.get("ResistanceZZ", 0))


class GeometryMagnet(Geometry):
    pass


class GeometryInventory(Geometry):
    def __init__(self, count: int = 1, *args, **kwargs):
        self.count = count

        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element", xml_parent: Optional["Element"] = None):
        super()._read_xml(xml_node, xml_parent)
        self.count = int(xml_node.attrib.get("Count", 1))


class GeometryBeam(Geometry):
    def __init__(
        self,
        lamp_type: "LampType" = LampType(None),
        power_consumption: float = 1000,
        luminous_flux: float = 10000,
        color_temperature: float = 6000,
        beam_angle: float = 25.0,
        field_angle: float = 25.0,
        beam_radius: float = 0.05,
        beam_type: BeamType = BeamType(None),
        color_rendering_index: int = 100,
        throw_ratio: float = 1.0,
        rectangle_ratio: float = 1.7777,
        emitter_spectrum: Optional["NodeLink"] = None,
        *args,
        **kwargs,
    ):
        self.lamp_type = lamp_type
        self.power_consumption = power_consumption
        self.luminous_flux = luminous_flux
        self.color_temperature = color_temperature
        self.beam_angle = beam_angle
        self.field_angle = field_angle
        self.beam_radius = beam_radius
        self.beam_type = beam_type
        self.color_rendering_index = color_rendering_index
        self.throw_ratio = throw_ratio
        self.rectangle_ratio = rectangle_ratio
        self.emitter_spectrum = emitter_spectrum
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element", xml_parent: Optional["Element"] = None):
        super()._read_xml(xml_node, xml_parent)
        self.lamp_type = LampType(xml_node.attrib.get("LampType"))
        self.power_consumption = float(xml_node.attrib.get("PowerConsumption", 1000))
        self.luminous_flux = float(xml_node.attrib.get("LuminousFlux", 10000))
        self.color_temperature = float(xml_node.attrib.get("ColorTemperature", 6000))
        self.beam_angle = float(xml_node.attrib.get("BeamAngle", 25))
        self.field_angle = float(xml_node.attrib.get("FieldAngle", 25))
        self.beam_radius = float(xml_node.attrib.get("BeamRadius", 0.05))
        self.beam_type = BeamType(xml_node.attrib.get("BeamType"))
        self.color_rendering_index = int(
            xml_node.attrib.get("ColorRenderingIndex", 100)
        )
        self.throw_ratio = float(xml_node.attrib.get("ThrowRatio", 1.0))
        self.rectangle_ratio = float(xml_node.attrib.get("RectangleRatio", 1.7777))
        self.emitter_spectrum = NodeLink(
            "EmitterCollect", xml_node.attrib.get("EmitterSpectrum")
        )

    def to_xml(self):
        attrs = {}
        if self.name is not None:
            attrs["Name"] = self.name
        if self.model is not None:
            attrs["Model"] = self.model
        if self.position is not None:
            attrs["Position"] = _matrix_to_str(self.position)
        if self.lamp_type and self.lamp_type.value is not None:
            attrs["LampType"] = str(self.lamp_type)
        attrs["PowerConsumption"] = f"{self.power_consumption:.6f}"
        attrs["LuminousFlux"] = f"{self.luminous_flux:.6f}"
        attrs["ColorTemperature"] = f"{self.color_temperature:.6f}"
        attrs["BeamAngle"] = f"{self.beam_angle:.6f}"
        attrs["FieldAngle"] = f"{self.field_angle:.6f}"
        attrs["BeamRadius"] = f"{self.beam_radius:.6f}"
        if self.beam_type and self.beam_type.value is not None:
            attrs["BeamType"] = str(self.beam_type)
        attrs["ColorRenderingIndex"] = str(self.color_rendering_index)
        attrs["ThrowRatio"] = f"{self.throw_ratio:.6f}"
        attrs["RectangleRatio"] = f"{self.rectangle_ratio:.6f}"
        if self.emitter_spectrum and self.emitter_spectrum.str_link:
            attrs["EmitterSpectrum"] = str(self.emitter_spectrum.str_link)
        return Element("Beam", attrs)


class GeometryLaser(Geometry):
    def __init__(
        self,
        color_type: "ColorType" = ColorType(None),
        color: float = 0,
        output_strength: float = 0,
        emitter: Optional["NodeLink"] = None,
        beam_diameter: float = 0,
        beam_divergence_min: float = 0,
        beam_divergence_max: float = 0,
        scan_angle_pan: float = 0,
        scan_angle_tilt: float = 0,
        scan_speed: float = 0,
        protocols: Optional[List["Protocol"]] = None,
        *args,
        **kwargs,
    ):
        self.color_type = color_type
        self.color = color
        self.output_strength = output_strength
        self.emitter = emitter
        self.beam_diameter = beam_diameter
        self.beam_divergence_min = beam_divergence_min
        self.beam_divergence_max = beam_divergence_max
        self.scan_angle_pan = scan_angle_pan
        self.scan_angle_tilt = scan_angle_tilt
        self.scan_speed = scan_speed
        self.protocols = protocols if protocols is not None else []
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element", xml_parent: Optional["Element"] = None):
        super()._read_xml(xml_node, xml_parent)
        self.color_type = ColorType(xml_node.attrib.get("ColorType"))
        self.color = float(xml_node.attrib.get("Color", 530))  # Green
        self.output_strength = float(xml_node.attrib.get("OutputStrength", 1))
        self.emitter = NodeLink("EmitterCollect", xml_node.attrib.get("Emitter"))
        self.beam_diameter = float(xml_node.attrib.get("BeamDiameter", 0.005))
        self.beam_divergence_min = float(xml_node.attrib.get("BeamDivergenceMin", 0))
        self.beam_divergence_max = float(xml_node.attrib.get("BeamDivergenceMax", 0))
        self.scan_angle_pan = float(xml_node.attrib.get("ScanAnglePan", 30))
        self.scan_angle_tilt = float(xml_node.attrib.get("ScanAngleTilt", 30))
        self.scan_speed = float(xml_node.attrib.get("ScanSpeed", 0))
        self.protocols = [Protocol(xml_node=i) for i in xml_node.findall("Protocol")]

    def to_xml(self):
        attrs = {}
        if self.name is not None:
            attrs["Name"] = self.name
        if self.model is not None:
            attrs["Model"] = self.model
        if self.position is not None:
            attrs["Position"] = _matrix_to_str(self.position)
        if self.color_type and self.color_type.value is not None:
            attrs["ColorType"] = str(self.color_type)
        attrs["Color"] = f"{self.color:.6f}"
        attrs["OutputStrength"] = f"{self.output_strength:.6f}"
        if self.emitter and self.emitter.str_link:
            attrs["Emitter"] = str(self.emitter.str_link)
        attrs["BeamDiameter"] = f"{self.beam_diameter:.6f}"
        attrs["BeamDivergenceMin"] = f"{self.beam_divergence_min:.6f}"
        attrs["BeamDivergenceMax"] = f"{self.beam_divergence_max:.6f}"
        attrs["ScanAnglePan"] = f"{self.scan_angle_pan:.6f}"
        attrs["ScanAngleTilt"] = f"{self.scan_angle_tilt:.6f}"
        attrs["ScanSpeed"] = f"{self.scan_speed:.6f}"

        element = Element(self._tag(), attrs)
        for protocol in self.protocols:
            element.append(protocol.to_xml())
        return element


class Protocol(BaseNode):
    def __init__(
        self,
        name: Optional[str] = None,
        *args,
        **kwargs,
    ):
        self.name = name
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element", xml_parent: Optional["Element"] = None):
        self.name = xml_node.attrib.get("Name")

    def __str__(self):
        return f"{self.name}"

    def to_xml(self):
        attrs = {}
        if self.name is not None:
            attrs["Name"] = self.name
        return Element("Protocol", attrs)


class PinPatch(BaseNode):
    def __init__(
        self,
        to_wiring_object: Optional["NodeLink"] = None,
        from_pin: int = 0,
        to_pin: int = 0,
        *args,
        **kwargs,
    ):
        self.to_wiring_object = to_wiring_object
        self.from_pin = from_pin
        self.to_pin = to_pin
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element", xml_parent: Optional["Element"] = None):
        self.to_wiring_object = NodeLink(
            "WiringObject", xml_node.attrib.get("ToWiringObject")
        )
        self.from_pin = int(xml_node.attrib.get("FromPin", 0))
        self.to_pin = int(xml_node.attrib.get("ToPin", 0))

    def to_xml(self):
        attrs = {
            "FromPin": str(self.from_pin),
            "ToPin": str(self.to_pin),
        }
        if self.to_wiring_object and self.to_wiring_object.str_link:
            attrs["ToWiringObject"] = str(self.to_wiring_object.str_link)
        return Element("PinPatch", attrs)


class GeometryWiringObject(Geometry):
    def __init__(
        self,
        connector_type: Optional[str] = None,
        component_type: "ComponentType" = ComponentType(None),
        signal_type: Optional[str] = None,
        pin_count: int = 0,
        electrical_payload: float = 0,
        voltage_range_max: float = 0,
        voltage_range_min: float = 0,
        frequency_range_max: float = 0,
        frequency_range_min: float = 0,
        max_payload: float = 0,
        voltage: float = 0,
        signal_layer: int = 0,
        cos_phi: float = 0,
        fuse_current: float = 0,
        fuse_rating: "FuseRating" = FuseRating(None),
        orientation: "Orientation" = Orientation(None),
        wire_group: Optional[str] = None,
        pin_patches: Optional[List["PinPatch"]] = None,
        *args,
        **kwargs,
    ):
        self.connector_type = connector_type
        self.component_type = component_type
        self.signal_type = signal_type
        self.pin_count = pin_count
        self.electrical_payload = electrical_payload
        self.voltage_range_max = voltage_range_max
        self.voltage_range_min = voltage_range_min
        self.frequency_range_min = frequency_range_min
        self.frequency_range_max = frequency_range_max
        self.max_payload = max_payload
        self.voltage = voltage
        self.signal_layer = signal_layer
        self.cos_phi = cos_phi
        self.fuse_current = fuse_current
        self.fuse_rating = fuse_rating
        self.orientation = orientation
        self.wire_group = wire_group
        self.pin_patches = pin_patches if pin_patches is not None else []
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element", xml_parent: Optional["Element"] = None):
        super()._read_xml(xml_node, xml_parent)
        self.connector_type = xml_node.attrib.get("ConnectorType")
        self.component_type = ComponentType(xml_node.attrib.get("ComponentType"))
        self.signal_type = xml_node.attrib.get("SignalType")
        self.pin_count = int(xml_node.attrib.get("PinCount", 0))
        self.electrical_payload = float(xml_node.attrib.get("ElectricalPayLoad", 0))
        self.voltage_range_max = float(xml_node.attrib.get("VoltageRangeMax", 0))
        self.voltage_range_min = float(xml_node.attrib.get("VoltageRangeMin", 0))
        self.frequency_range_max = float(xml_node.attrib.get("FrequencyRangeMax", 0))
        self.frequency_range_min = float(xml_node.attrib.get("FrequencyRangeMin", 0))
        self.max_payload = float(xml_node.attrib.get("MaxPayLoad", 0))
        self.voltage = float(xml_node.attrib.get("Voltage", 0))
        self.signal_layer = int(xml_node.attrib.get("SignalLayer", 0))
        self.cos_phi = float(xml_node.attrib.get("CosPhi", 0))
        self.fuse_current = float(xml_node.attrib.get("FuseCurrent", 0))
        self.fuse_rating = FuseRating(xml_node.attrib.get("FuseRating"))
        self.orientation = Orientation(xml_node.attrib.get("Orientation"))
        self.wire_group = xml_node.attrib.get("WireGroup")
        self.pin_patches = [PinPatch(xml_node=i) for i in xml_node.findall("PinPatch")]

    def to_xml(self):
        attrs = {}
        if self.name is not None:
            attrs["Name"] = self.name
        if self.model is not None:
            attrs["Model"] = self.model
        if self.position is not None:
            attrs["Position"] = _matrix_to_str(self.position)
        if self.connector_type is not None:
            attrs["ConnectorType"] = self.connector_type
        if self.component_type and self.component_type.value is not None:
            attrs["ComponentType"] = str(self.component_type)
        if self.signal_type is not None:
            attrs["SignalType"] = self.signal_type
        attrs["PinCount"] = str(self.pin_count)
        attrs["ElectricalPayLoad"] = f"{self.electrical_payload:.6f}"
        attrs["VoltageRangeMax"] = f"{self.voltage_range_max:.6f}"
        attrs["VoltageRangeMin"] = f"{self.voltage_range_min:.6f}"
        attrs["FrequencyRangeMax"] = f"{self.frequency_range_max:.6f}"
        attrs["FrequencyRangeMin"] = f"{self.frequency_range_min:.6f}"
        attrs["MaxPayLoad"] = f"{self.max_payload:.6f}"
        attrs["Voltage"] = f"{self.voltage:.6f}"
        attrs["SignalLayer"] = str(self.signal_layer)
        attrs["CosPhi"] = f"{self.cos_phi:.6f}"
        attrs["FuseCurrent"] = f"{self.fuse_current:.6f}"
        if self.fuse_rating and self.fuse_rating.value is not None:
            attrs["FuseRating"] = str(self.fuse_rating)
        if self.orientation and self.orientation.value is not None:
            attrs["Orientation"] = str(self.orientation)
        if self.wire_group is not None:
            attrs["WireGroup"] = self.wire_group

        element = Element(self._tag(), attrs)
        for pin_patch in self.pin_patches:
            element.append(pin_patch.to_xml())
        return element


class GeometryReference(BaseNode):
    def __init__(
        self,
        name: Optional[str] = None,
        parent_name: Optional[str] = None,
        position: "Matrix" = Matrix(0),
        geometry: Optional[str] = None,
        model: Optional[str] = None,
        *args,
        **kwargs,
    ):
        self.name = name
        self.parent_name = parent_name
        self.position = position
        self.geometry = geometry
        self.model = model
        self.breaks: List["Break"] = []
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element", xml_parent: Optional["Element"] = None):
        self.name = xml_node.attrib.get("Name")

        if xml_parent is not None:
            self.parent_name = xml_parent.get("Name")

        self.position = Matrix(xml_node.attrib.get("Position", 0))
        self.geometry = xml_node.attrib.get("Geometry")
        self.model = xml_node.attrib.get("Model")
        self.breaks = [Break(xml_node=i) for i in xml_node.findall("Break")]

    def __str__(self):
        return f"{self.name} ({self.model})"

    def to_xml(self):
        attrs = {}
        if self.name is not None:
            attrs["Name"] = self.name
        if self.model is not None:
            attrs["Model"] = self.model
        if self.position is not None:
            attrs["Position"] = _matrix_to_str(self.position)
        if self.geometry is not None:
            attrs["Geometry"] = self.geometry

        element = Element("GeometryReference", attrs)
        for br in getattr(self, "breaks", []):
            element.append(br.to_xml())
        return element


TAG_TO_GEOMETRY_CLASS = {
    "Geometry": Geometry,
    "Axis": GeometryAxis,
    "FilterBeam": GeometryFilterBeam,
    "FilterColor": GeometryFilterColor,
    "FilterGobo": GeometryFilterGobo,
    "FilterShaper": GeometryFilterShaper,
    "MediaServerMaster": GeometryMediaServerMaster,
    "MediaServerLayer": GeometryMediaServerLayer,
    "MediaServerCamera": GeometryMediaServerCamera,
    "Inventory": GeometryInventory,
    "Beam": GeometryBeam,
    "WiringObject": GeometryWiringObject,
    "GeometryReference": GeometryReference,
    "Laser": GeometryLaser,
    "Structure": GeometryStructure,
    "Support": GeometrySupport,
    "Magnet": GeometryMagnet,
    "Display": GeometryDisplay,
}
CLASS_TO_GEOMETRY_TAG = {cls: tag for tag, cls in TAG_TO_GEOMETRY_CLASS.items()}
