"""See README.md for package information."""

__version__ = '0.6.0'
